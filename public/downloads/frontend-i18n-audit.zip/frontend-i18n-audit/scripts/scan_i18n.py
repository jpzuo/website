#!/usr/bin/env python3
"""Frontend i18n audit — local scan, no network, no code upload.

Scans TS/JS/Vue source for hardcoded Chinese strings, generates
globally-unique Keys following module.sub-item (lowercase, dot-separated),
checks missing English translations and duplicate Keys, and writes
report.md + i18n-import.csv.

Usage:
    python3 scripts/scan_i18n.py --src ./demo/sample-project/src --out ./demo/sample-output
    python3 scripts/scan_i18n.py --src ./src --locales ./locales --out ./i18n-audit-output
"""
import argparse
import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

CHINESE_RE = re.compile(r"[\u4e00-\u9fff]+")
# Quoted strings, template literals, and JSX text containing Chinese.
QUOTED_RE = re.compile(r"""(?:"([^"\n]*[\u4e00-\u9fff][^"\n]*)"|'([^'\n]*[\u4e00-\u9fff][^'\n]*)'|`([^`\n]*[\u4e00-\u9fff][^`\n]*)`)""")
JSX_RE = re.compile(r">([^<>{}]*[\u4e00-\u9fff][^<>{}]*)<")
EXTS = {".ts", ".tsx", ".js", ".jsx", ".vue"}

# Small built-in draft map for the most common UI words.
# This is only a draft — the CSV marks every English value as needing human review.
COMMON_EN = {
    "登录": "Sign in", "注册": "Sign up", "确定": "Confirm", "取消": "Cancel",
    "保存": "Save", "删除": "Delete", "编辑": "Edit", "搜索": "Search",
    "欢迎回来": "Welcome back", "请输入密码": "Please enter your password",
    "请输入用户名": "Please enter your username", "用户名": "Username",
    "密码": "Password", "首页": "Home", "设置": "Settings",
    "提交": "Submit", "返回": "Back", "下一步": "Next",
    "加载中": "Loading...", "操作成功": "Success", "操作失败": "Failed",
    "确认删除吗": "Are you sure you want to delete?",
    "欢迎使用": "Welcome", "退出登录": "Sign out",
}
COMMON_SLUG = {
    "登录": "sign-in", "注册": "sign-up", "确定": "confirm", "取消": "cancel",
    "保存": "save", "删除": "delete", "编辑": "edit", "搜索": "search",
    "欢迎回来": "welcome-back", "请输入密码": "enter-password",
    "请输入用户名": "enter-username", "用户名": "username",
    "密码": "password", "首页": "home", "设置": "settings",
    "提交": "submit", "返回": "back", "下一步": "next",
    "加载中": "loading", "操作成功": "success", "操作失败": "failed",
    "确认删除吗": "confirm-delete",
    "欢迎使用": "welcome", "退出登录": "sign-out",
}


def strip_comments(text: str, suffix: str) -> str:
    # Lightweight comment stripping for .ts/.js/.vue script parts.
    # Keep it conservative: only full-line // comments and /* */ blocks.
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("//"):
            continue
        lines.append(line)
    return "\n".join(lines)


def infer_module(path: Path, src_root: Path, forced: str | None) -> str:
    if forced:
        return forced.lower()
    try:
        rel = path.relative_to(src_root)
    except ValueError:
        rel = path
    parts = [p for p in rel.parts if p not in ("src",)]
    # src/pages/login/Login.tsx -> login ; src/components/Button.tsx -> common
    if len(parts) >= 2 and parts[0] in ("pages", "views", "modules", "features"):
        return re.sub(r"[^a-z0-9]+", "-", parts[1].lower()).strip("-") or "common"
    if len(parts) >= 2 and parts[0] in ("components", "common", "shared"):
        return "common"
    if parts:
        return re.sub(r"[^a-z0-9]+", "-", parts[0].lower()).strip("-") or "common"
    return "common"


def extract(path: Path):
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    clean = strip_comments(text, path.suffix)
    found = []
    for i, line in enumerate(clean.splitlines(), start=1):
        for m in QUOTED_RE.finditer(line):
            val = next(g for g in m.groups() if g is not None).strip()
            if CHINESE_RE.search(val):
                found.append((i, val))
        for m in JSX_RE.finditer(line):
            val = m.group(1).strip()
            if CHINESE_RE.search(val):
                found.append((i, val))
    return found


def slug_for(zh: str, used: Counter) -> str:
    base = COMMON_SLUG.get(zh)
    if not base:
        # Fallback: short stable slug, never invents a fake translation.
        base = "text"
    return base


def main() -> int:
    ap = argparse.ArgumentParser(description="Frontend i18n audit (local only)")
    ap.add_argument("--src", required=True, help="Frontend source directory, e.g. ./src")
    ap.add_argument("--locales", default=None, help="Directory with zh.json / en.json")
    ap.add_argument("--out", default="./i18n-audit-output", help="Output directory")
    ap.add_argument("--module", default=None, help="Force module name")
    args = ap.parse_args()

    src_root = Path(args.src)
    if not src_root.is_dir():
        print(f"src not found: {src_root}", file=sys.stderr)
        return 2
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    files = sorted(p for p in src_root.rglob("*") if p.is_file() and p.suffix in EXTS
                   and "node_modules" not in p.parts and "dist" not in p.parts)
    # zh -> first occurrence
    seen: dict[str, dict] = {}
    for f in files:
        module = infer_module(f, src_root, args.module)
        for lineno, zh in extract(f):
            zh_clean = re.sub(r"\s+", " ", zh).strip()
            if not zh_clean:
                continue
            if zh_clean not in seen:
                seen[zh_clean] = {"zh": zh_clean, "file": str(f), "line": lineno,
                                  "module": module, "count": 1}
            else:
                seen[zh_clean]["count"] += 1

    # Load existing locales for duplicate / missing checks.
    zh_keys: dict[str, str] = {}
    en_keys: dict[str, str] = {}
    if args.locales:
        loc = Path(args.locales)
        for name, store in (("zh.json", zh_keys), ("en.json", en_keys)):
            p = loc / name
            if p.is_file():
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        store.update({str(k): str(v) for k, v in data.items()})
                except Exception as e:
                    print(f"warning: cannot read {p}: {e}", file=sys.stderr)

    # Generate Keys, globally unique.
    used_slugs: dict[str, Counter] = defaultdict(Counter)
    rows = []
    for zh, info in sorted(seen.items()):
        module = info["module"]
        base = slug_for(zh, used_slugs[module])
        used_slugs[module][base] += 1
        n = used_slugs[module][base]
        slug = base if n == 1 else f"{base}-{n}"
        key = f"{module}.{slug}"
        en_draft = COMMON_EN.get(zh, "")
        # If locales already have this zh, reuse its key.
        existing_key = next((k for k, v in zh_keys.items() if v == zh), None)
        if existing_key:
            key = existing_key
        missing_en = not en_draft and key not in en_keys
        rows.append({**info, "key": key, "en": en_draft,
                     "missing_en": missing_en, "existing_key": bool(existing_key)})

    # Duplicate-key check: same key, different zh in locales.
    dup_keys = [k for k, c in Counter(v for v in zh_keys.values()).items() if c > 1]
    missing_en_count = sum(1 for r in rows if r["missing_en"] or not r["en"])
    naming_bad = [r for r in rows if not re.fullmatch(r"[a-z0-9]+(\.[a-z0-9-]+)+", r["key"])]

    # Write CSV (bulk-import format for the i18n module).
    csv_path = out_dir / "i18n-import.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["key", "zh", "en", "module", "note"])
        for r in rows:
            note = "需人工确认英文" if not r["en"] else "英文为草稿，需人工确认"
            if r["existing_key"]:
                note += "；沿用已有Key"
            w.writerow([r["key"], r["zh"], r["en"], r["module"], note])

    # Write report.
    report_path = out_dir / "report.md"
    top = sorted(rows, key=lambda r: (-r["count"], r["zh"]))[:10]
    lines = [
        "# i18n 体检报告",
        "",
        f"- 扫描文件：{len(files)} 个",
        f"- 硬编码中文：{sum(r['count'] for r in rows)} 条（去重后 {len(rows)} 条）",
        f"- 缺英文：{missing_en_count} 条",
        f"- Key 重复（已有语言文件内）：{len(dup_keys)} 处",
        f"- 命名违规：{len(naming_bad)} 处",
        "",
        "## 优先修复 Top 10",
        "",
        "| # | 文件:行 | 中文 | 建议 Key | 建议英文 |",
        "|---|---|---|---|---|",
    ]
    for i, r in enumerate(top, start=1):
        lines.append(f"| {i} | {r['file']}:{r['line']} | {r['zh']} | {r['key']} | {r['en'] or '（待补）'} |")
    lines += [
        "",
        "## 全部清单",
        "",
        "| 文件:行 | 中文 | 建议 Key | 出现次数 |",
        "|---|---|---|---|",
    ]
    for r in rows:
        lines.append(f"| {r['file']}:{r['line']} | {r['zh']} | {r['key']} | {r['count']} |")
    lines += ["", "结论：先修 Top 10，再按模块批量补英文，导入前先在测试环境导 5 条验证。"]
    report_path.write_text("\n".join(lines), encoding="utf-8")

    print(f"扫描文件：{len(files)} 个")
    print(f"硬编码中文：{sum(r['count'] for r in rows)} 条（去重后 {len(rows)} 条）")
    print(f"缺英文：{missing_en_count} 条")
    print(f"报告：{report_path}")
    print(f"导入表：{csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
