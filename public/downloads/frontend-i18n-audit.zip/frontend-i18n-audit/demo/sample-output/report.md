# i18n 体检报告

- 扫描文件：3 个
- 硬编码中文：14 条（去重后 14 条）
- 缺英文：0 条
- Key 重复（已有语言文件内）：0 处
- 命名违规：0 处

## 优先修复 Top 10

| # | 文件:行 | 中文 | 建议 Key | 建议英文 |
|---|---|---|---|---|
| 1 | demo/sample-project/src/pages/home/Home.tsx:3 | 加载中 | home.loading | Loading... |
| 2 | demo/sample-project/src/components/ConfirmDialog.tsx:7 | 取消 | common.cancel | Cancel |
| 3 | demo/sample-project/src/pages/login/Login.tsx:7 | 密码 | login.password | Password |
| 4 | demo/sample-project/src/pages/home/Home.tsx:2 | 欢迎使用 | home.welcome | Welcome |
| 5 | demo/sample-project/src/pages/login/Login.tsx:4 | 欢迎回来 | login.welcome-back | Welcome back |
| 6 | demo/sample-project/src/pages/login/Login.tsx:10 | 注册 | login.sign-up | Sign up |
| 7 | demo/sample-project/src/pages/login/Login.tsx:5 | 用户名 | login.username | Username |
| 8 | demo/sample-project/src/pages/login/Login.tsx:9 | 登录 | login.sign-in | Sign in |
| 9 | demo/sample-project/src/components/ConfirmDialog.tsx:6 | 确定 | common.confirm | Confirm |
| 10 | demo/sample-project/src/components/ConfirmDialog.tsx:2 | 确认删除吗 | common.confirm-delete | Are you sure you want to delete? |

## 全部清单

| 文件:行 | 中文 | 建议 Key | 出现次数 |
|---|---|---|---|
| demo/sample-project/src/pages/home/Home.tsx:3 | 加载中 | home.loading | 1 |
| demo/sample-project/src/components/ConfirmDialog.tsx:7 | 取消 | common.cancel | 1 |
| demo/sample-project/src/pages/login/Login.tsx:7 | 密码 | login.password | 1 |
| demo/sample-project/src/pages/home/Home.tsx:2 | 欢迎使用 | home.welcome | 1 |
| demo/sample-project/src/pages/login/Login.tsx:4 | 欢迎回来 | login.welcome-back | 1 |
| demo/sample-project/src/pages/login/Login.tsx:10 | 注册 | login.sign-up | 1 |
| demo/sample-project/src/pages/login/Login.tsx:5 | 用户名 | login.username | 1 |
| demo/sample-project/src/pages/login/Login.tsx:9 | 登录 | login.sign-in | 1 |
| demo/sample-project/src/components/ConfirmDialog.tsx:6 | 确定 | common.confirm | 1 |
| demo/sample-project/src/components/ConfirmDialog.tsx:2 | 确认删除吗 | common.confirm-delete | 1 |
| demo/sample-project/src/pages/home/Home.tsx:8 | 设置 | home.settings | 1 |
| demo/sample-project/src/pages/login/Login.tsx:8 | 请输入密码 | login.enter-password | 1 |
| demo/sample-project/src/pages/login/Login.tsx:6 | 请输入用户名 | login.enter-username | 1 |
| demo/sample-project/src/pages/home/Home.tsx:9 | 退出登录 | home.sign-out | 1 |

结论：先修 Top 10，再按模块批量补英文，导入前先在测试环境导 5 条验证。