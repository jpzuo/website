export function Login() {
  return (
    <div>
      <h1>欢迎回来</h1>
      <label>用户名</label>
      <input placeholder="请输入用户名" />
      <label>密码</label>
      <input placeholder="请输入密码" />
      <button>登录</button>
      <button>注册</button>
    </div>
  );
}
