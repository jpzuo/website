export function Home() {
  const title = "欢迎使用";
  const loading = "加载中";
  return (
    <div>
      <h1>{title}</h1>
      <p>{loading}</p>
      <button>设置</button>
      <button>退出登录</button>
    </div>
  );
}
