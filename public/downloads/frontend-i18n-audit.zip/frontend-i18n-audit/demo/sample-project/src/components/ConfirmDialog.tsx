export function ConfirmDialog() {
  const msg = "确认删除吗";
  return (
    <div>
      <p>{msg}</p>
      <button>确定</button>
      <button>取消</button>
    </div>
  );
}
