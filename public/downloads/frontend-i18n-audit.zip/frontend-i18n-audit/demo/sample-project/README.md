# Demo 示例工程

一个 3 个文件的小示例，只用来演示扫描效果，不是真实业务代码。

跑法：

```bash
python3 ../../scripts/scan_i18n.py --src ./src --out ../sample-output
```

预期：扫描 3 个文件，硬编码 14 条、去重后 14 条，英文草稿都有、缺英文 0 条（草稿仍需人工确认），报告和 CSV 在 `../sample-output/`。实测 2026-11-06 已通过。
