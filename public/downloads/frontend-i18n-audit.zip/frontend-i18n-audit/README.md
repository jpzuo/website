# Frontend i18n Audit — 2026 华为开发者大赛 · 小红书 Skill 创新赛参赛作品

## 这是什么

给前端工程做国际化体检的 Skill：本地扫描硬编码中文，按 `module.sub-item` 规则生成全局唯一 Key，输出体检报告 + 可批量导入的 Key + 中英文对照表。

- 选题：通用赛道 / 开发工具（效率工具）
- 截止：2026-11-24（报名与提交同一天，组队截止 11-24 23:59:59，以官网最新显示为准）
- 官网：https://developer.huaweicloud.com/competition/information/1300000350/

## 目录

```
frontend-i18n-audit/
├── SKILL.md # 必填，技能定义，≤500 行
├── scripts/
│ └── scan_i18n.py # 本地扫描脚本，零依赖，只用 Python 3 标准库
├── references/
│ ├── i18n-key-rules.md # Key 命名规则
│ └── checklist.md # 提交前自查清单
├── assets/templates/
│ ├── i18n-import-template.csv
│ └── report-template.md
├── demo/
│ ├── sample-project/ # 3 个文件的演示工程
│ └── sample-output/ # 跑完脚本的标准输出
├── README.md # 本文件
└── xiaohongshu-note.md # 小红书“学一做一”笔记文案
```

## 本地试用（不用上传代码）

```bash
# 1. 跑演示
python3 scripts/scan_i18n.py --src./demo/sample-project/src --out./demo/sample-output

# 2. 跑自己的工程（只扫 src，排除 node_modules/dist）
python3 scripts/scan_i18n.py --src./src --locales./locales --out./i18n-audit-output
```

输出：`report.md` + `i18n-import.csv`（表头 `key,zh,en,module,note`）。

## 开发工具

本作品用华为云码道 CodeArts 开发。请在 CodeArts 里打开本目录做开发和调试，提交时保留 CodeArts 使用记录。也可以用果办 OfficeAce 提交，二选一即可。

## 提交三步（按官网“创作与提交”）

1. 小红书 Skill 市场：打开 https://www.xiaohongshu.com/skillcenter ，点为“华为开发者大赛的参赛作品”所设的，按提示填信息、上传 Skill 包，过审后复制专属链接。
2. 华为云 Skill 市场：打开 https://www.huaweicloud.com/product/aiskill.html ，点，完善技能名、简介、SKILL.md、Skill Package 压缩包，过审即上架。
3. 回大赛官网：登录后进“大赛详情-创作与提交”，点，填参赛信息、两个市场的链接、标题，提交。

另：作品也可通过华为云码道 CodeArts（网页端或 IDE）或果办 OfficeAce 提交。

## 小红书笔记

必须发“学一做一”笔记（视频或图文），展示使用体验，带 3 个标签并 @小红书AI开放平台，附上架链接和使用截图。文案见 `xiaohongshu-note.md`。视频时长官网有两个说法（不少于 2 分钟 / 不少于 30 秒），按 2 分钟准备。

## 自查

- 包 ≤40MB、文件 ≤30 个；SKILL.md ≤500 行
- 英文均为草稿，需人工确认；不修改业务源码
- 规则来源：国际化管理模块 V0.1 §3.1 命名规则、§2.6 埋点场景
