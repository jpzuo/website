---
name: frontend-i18n-audit
description: "Audit a frontend project for i18n readiness: find hardcoded Chinese strings in TS/JS/Vue files, generate globally-unique Keys following module.sub-item lowercase dot-separated naming, check missing English translations and duplicate Keys, and output a fix list plus a bulk-import CSV for an i18n management module. Use when the user says 前端国际化, 硬编码中文, i18n体检, 缺翻译, Key命名, 文案出海, 多语言, or wants to scan a frontend project before going multilingual. Do not use for backend-only i18n, for machine translation quality review, or for a project with no frontend code."
version: 1.0.0
author: zuo
tags:
  - frontend
  - i18n
  - audit
  - xiaohongshu-skill
tools:
  - python3
created: 2026-11-06
updated: 2026-11-06
license: MIT
---

# Frontend i18n Audit — 前端国际化体检

给前端工程做一次“出海前体检”：不用上传业务代码，本地跑一个脚本，10 分钟找出所有硬编码中文、缺英文翻译、Key 命名不规范的问题，输出能直接进国际化管理模块批量导入的 Key + 中英文对照表。

适用：React / Vue / 纯 TS/JS 前端工程，准备做中英切换、出海、或接国际化管理模块的团队。只做体检和清单，不自动改你的业务代码，不调用任何翻译 API，不上传代码到远端。

## 一、技能任务概述

**定位：** 一个可复用的前端国际化体检 Skill。输入是一个前端工程路径，输出是一份体检报告 + 一份可导入的文案表。

**输出目标：**
- 硬编码中文清单：文件、行号、原文、建议 Key、建议英文草稿。
- Key 命名合规检查：是否符合 `module.sub-item` 规则，全小写点分、全局唯一。
- 缺失检查：中文有、英文缺；英文有、中文缺；Key 重复；Key 声明了但代码里没用。
- 可导入文件：`i18n-import.csv`，列为 Key、中文、英文、所属模块、备注，可直接用于批量导入。

**适用场景：**
- 上线多语言切换前，先扫一遍硬编码。
- 接国际化管理模块前，先把文案 Key 理清楚。
- Code Review 时快速判断一个 PR 有没有新增硬编码中文。
- 小红书 / 出海项目要做英文版，先拿到工作量清单。

**不适用：** 没有前端代码的纯后端项目；只想评测机器翻译质量；需要自动把全站翻成 10 种语言。

## 二、核心工作流

按顺序执行，不要跳步。Agent 每一步都要把结果写进报告，不要只在对话里口头说。

### Step 1 — 确认范围

1. 问用户要扫描的工程路径，默认当前目录。确认只扫源码目录，如 `src/`，排除 `node_modules/`、`dist/`、`.git/`。
2. 确认文件类型：默认 `.ts`、`.tsx`、`.js`、`.jsx`、`.vue`。
3. 确认已有语言文件：如果有 `locales/zh.json` / `en.json`，一起读入做对照；没有就只做硬编码扫描，缺失英文标记为“待补”。
4. 确认模块名：从工程路径或页面路径推断，如 `src/pages/login/` 对应模块 `login`。用户没给模块名时，用目录名做模块名。

### Step 2 — 本地扫描

运行本地脚本，不要把代码贴给远端模型逐行读：

```bash
python3 scripts/scan_i18n.py --src ./demo/sample-project/src --locales ./demo/sample-project/locales --out ./demo/sample-output
```

脚本只做确定性工作：正则提取中文字符串、去重、按规则生成 Key、对照语言文件。不要让模型凭感觉编 Key。

### Step 3 — 生成 Key 并校验

Key 生成规则（必须遵守，见 `references/i18n-key-rules.md`）：
- 格式：`module.sub-item`，全小写英文字母、数字、点分隔，全局唯一。
- `module` 是页面或功能模块，如 `login`、`home`、`common`。
- `sub-item` 用英文短词描述文案，如 `login.title`、`login.submit`、`common.confirm`。
- 同一个中文在不同模块出现，要加模块前缀区分，不要共用一个 Key。
- 已有 Key 的，沿用已有 Key，不要新造。

校验项：
- Key 重复：同一个 Key 对应两个不同中文，标为错误。
- 翻译缺失：中文有、英文空，标为待补；英文有、中文空，标为待补。
- 命名违规：含大写、含下划线、含中文、含空格、连续点，标为违规并给出修正建议。
- 占位符：带 `{name}`、`%s`、`{{count}}` 的文案，中英文占位符必须一致。

### Step 4 — 输出报告和导入表

脚本输出两个文件：
- `report.md`：总数、分类统计、逐条清单、修复优先级。
- `i18n-import.csv`：Key、中文、英文、所属模块、备注。

Agent 再按报告写一段 200 字以内的结论：先说总数和最严重的 3 类问题，再说建议先修哪 10 条。不要只贴表格不给结论。

### Step 5 — 复查

1. 用户修完后，重新跑一次脚本，对比两次报告，确认硬编码数下降。
2. 导入国际化管理模块前，先在测试环境导 5 条验证列顺序和 Key 唯一校验，再全量导入。
3. 把两次报告都留档，作为操作日志的附件。

## 三、输入输出规范

### 输入

| 参数 | 必填 | 说明 | 示例 |
|---|---|---|---|
| `src` | 是 | 前端源码目录 | `./src` |
| `locales` | 否 | 已有语言文件目录，含 `zh.json` / `en.json` | `./locales` |
| `out` | 否 | 输出目录，默认 `./i18n-audit-output` | `./demo/sample-output` |
| `module` | 否 | 强制指定模块名，不指定则按目录推断 | `login` |

### 输出

**1. `report.md`（必填）**

```markdown
# i18n 体检报告
- 扫描文件：xx 个
- 硬编码中文：xx 条（去重后 xx 条）
- 缺英文：xx 条
- Key 重复：xx 处
- 命名违规：xx 处

## 优先修复 Top 10
| # | 文件:行 | 中文 | 建议 Key | 建议英文 |
```

**2. `i18n-import.csv`（必填）**

表头必须是：`key,zh,en,module,note`

示例：

```csv
key,zh,en,module,note
login.title,欢迎回来,Welcome back,login,登录页标题
login.submit,登录,Sign in,login,登录按钮
common.confirm,确定,Confirm,common,通用确认
```

注意：CSV 用 UTF-8 编码，含逗号的文案加双引号。英文为空时留空，不要填“待翻译”三个字进英文列。

**3. 结论（必填，200 字以内）**

先报总数，再报最严重的 3 类问题，最后给先修的 10 条。不要写“整体良好”这种空话。

## 四、质量规范

**准确性：**
- 只报脚本实际扫到的中文，不编造文件和行号。行号以脚本输出为准。
- 建议英文只是草稿，必须标明“需人工确认”，不要当成定稿。
- 同一个中文在同一文件出现多次，只列一次，注明出现次数。

**一致性：**
- 同一个中文在全工程只对应一个 Key，同一个 Key 只对应一个中文。
- 模块名、Key 命名全工程统一，不要一会儿 `login` 一会儿 `Login`。

**合规性：**
- 全程本地运行，不上传业务代码，不调用外部翻译接口。
- 不修改业务源码，只输出报告和导入表。改代码由用户确认后另行操作。
- 不收集用户隐私文案，报告里只列界面文案，不列接口密钥、手机号、身份证号。

**可维护性：**
- 脚本零第三方依赖，只用 Python 3 标准库，`python3 scripts/scan_i18n.py --help` 必须能跑。
- 规则改动只改 `references/i18n-key-rules.md` 和脚本里的常量，不要在 SKILL.md 里藏第二套规则。
- 示例必须能复现：`demo/sample-project` 跑出来的结果要和 `demo/sample-output` 一致。

## 五、参考资料与应用示例

- 规则详解：`references/i18n-key-rules.md` — Key 命名、27 类埋点场景分类、占位符规则。
- 自查清单：`references/checklist.md` — 提交前逐项打勾。
- 导入模板：`assets/templates/i18n-import-template.csv` — 空表头，可直接填。
- 报告模板：`assets/templates/report-template.md`
- 演示：`demo/sample-project/` 是一个 3 个文件的小示例工程，含登录页、首页、通用组件的硬编码中文；`demo/sample-output/` 是跑完脚本后的标准输出，对照着看就知道报告长什么样。

**示例 1 — 登录页只有 3 处硬编码：**

```bash
python3 scripts/scan_i18n.py --src ./demo/sample-project/src --out ./demo/sample-output
# 输出：扫描 3 个文件，硬编码 7 条，去重后 5 条，缺英文 5 条
```

**示例 2 — 已有语言文件，做对照检查：**

```bash
python3 scripts/scan_i18n.py --src ./src --locales ./locales --out ./i18n-audit-output
# 输出：report.md + i18n-import.csv，含 Key 重复和缺失统计
```

**提交说明：** 本作品用华为云码道 CodeArts 开发，提交时同时发布到华为云 Skill 市场和小红书 Skill 市场，并在小红书发“学一做一”笔记展示使用过程。详见 `README.md`。
